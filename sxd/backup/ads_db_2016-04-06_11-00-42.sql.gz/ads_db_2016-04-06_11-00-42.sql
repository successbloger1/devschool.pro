#SXD20|20011|50547|50445|2016.04.06 11:00:42|ads_db|utf8|3|18|
#TA ads`0`16384|category`9`268|location`9`276
#EOH

#	TC`ads`utf8_general_ci	;
CREATE TABLE `ads` (
  `id` varchar(20) NOT NULL,
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `seller_name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `allow_mails` varchar(2) NOT NULL DEFAULT '',
  `phone` varchar(11) NOT NULL,
  `location_id` varchar(6) NOT NULL DEFAULT '0',
  `category_id` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`category`utf8_general_ci	;
CREATE TABLE `category` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`category`utf8_general_ci	;
INSERT INTO `category` VALUES 
(1,'-- Выберите категорию --'),
(2,'Транспорт'),
(3,'Недвижимость'),
(4,'Работа'),
(5,'Услуги'),
(6,'Личные вещи'),
(7,'Для дома и дачи'),
(8,'Бытовая электроника'),
(9,'Прочее')	;
#	TC`location`utf8_general_ci	;
CREATE TABLE `location` (
  `id` varchar(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`location`utf8_general_ci	;
INSERT INTO `location` VALUES 
('0','-- Выберите город --'),
('641780','Новосибирск'),
('641490','Барабинск'),
('641510','Бердск'),
('641600','Искитим'),
('641630','Колывань'),
('641680','Краснообск'),
('641710','Куйбышев'),
('641760','Мошково')	;
